
export default function App(){
  return <h1>Trailer Pallet Tracker – FINAL</h1>
}
