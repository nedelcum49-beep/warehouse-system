
from fastapi import FastAPI, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session
from .db import engine, get_db
from . import models
from .pdf import generate_label
from .zpl import trailer_zpl

models.Base.metadata.create_all(bind=engine)
app = FastAPI()

@app.get("/label/pdf/{code}")
def pdf(code:str):
    return Response(generate_label(code), media_type="application/pdf")

@app.get("/label/zpl/{code}")
def zpl(code:str):
    return Response(trailer_zpl(code), media_type="text/plain")
