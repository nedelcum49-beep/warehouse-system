
from io import BytesIO
from reportlab.lib.pagesizes import A6
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
import barcode
from barcode.writer import ImageWriter

def generate_label(code):
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A6)
    w,h = A6
    c.setFont("Helvetica-Bold",24)
    c.drawCentredString(w/2,h-30*mm,code)
    bc = barcode.get("code128",code,writer=ImageWriter())
    img = BytesIO(); bc.write(img); img.seek(0)
    c.drawImage(img,10*mm,h-80*mm,width=w-20*mm)
    c.showPage(); c.save()
    buf.seek(0)
    return buf.read()
