
def trailer_zpl(code):
    return f"""^XA
^CF0,60
^FO50,30^FDTRAILER^FS
^FO50,120^FD{code}^FS
^BY3
^FO50,200^BCN,120,Y,N,N
^FD{code}^FS
^XZ"""
