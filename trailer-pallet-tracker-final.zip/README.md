
FINAL Trailer Pallet Tracker

Run:
docker compose up --build

Web UI: http://localhost
API: http://localhost:8000
